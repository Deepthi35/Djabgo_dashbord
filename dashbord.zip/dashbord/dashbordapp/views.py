from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from .models import Dashborddata


def index(request):
    dashbord = Dashborddata.objects.all()
    context = {
        "dashbord": dashbord
    }
    return render(request, 'index.html', context)
# views.py


def get_json_data(request):
    json_data = Dashborddata.objects.all()
    data = [
        {
            'department': entry.department,
            'monthlyincome': entry.monthlyincome,
            'gender': entry.gender,
            'age': entry.age,
            'attrition': entry.attrition,
            'businesstravel': entry.businesstravel,
            'dailyrate': entry.dailyrate,
            'education': entry.education,
            'educationfield': entry.educationfield,
            'employeecount': entry.employeecount,
            'employeenumber': entry.employeenumber,
            'environmentsatisfaction': entry.environmentsatisfaction,
            'hourlyrate': entry.hourlyrate,
            'jobinvolvement': entry.jobinvolvement,
            'joblevel': entry.joblevel,
            'jobrole': entry.jobrole,
            'jobsatisfaction': entry.jobsatisfaction,
            'maritalstatus': entry.maritalstatus,
            'monthlyincome': entry.monthlyincome,
            'monthlyrate': entry.monthlyrate,
            'numcompaniesworked': entry.numcompaniesworked,
            'over18': entry.over18,
            'overtime': entry.overtime,
            'percentsalaryhike': entry.percentsalaryhike,
            'performancerating': entry.performancerating,
            'relationshipsatisfaction': entry.relationshipsatisfaction,
            'standardhours': entry.standardhours,
            'stockoptionlevel': entry.stockoptionlevel,
            'totalworkingyears': entry.totalworkingyears,
            'trainingtimeslastyear': entry.trainingtimeslastyear,
            'worklifebalance': entry.worklifebalance,
            'yearsatcompany': entry.yearsatcompany,
            'yearsincurrentrole': entry.yearsincurrentrole,
            'yearssincelastpromotion': entry.yearssincelastpromotion,
            'yearswithcurrmanager': entry.yearswithcurrmanager
        }
        for entry in json_data
    ]
    return JsonResponse(data, safe=False)


def chart(request):
    dashbord = Dashborddata.objects.all()
    context1 = {
        "dashbord": dashbord
    }
    return render(request, 'chart.html', context1)


def table(request):
    dashbord = Dashborddata.objects.all()
    context1 = {
        "dashbord": dashbord
    }
    return render(request, 'table.html', context1)
