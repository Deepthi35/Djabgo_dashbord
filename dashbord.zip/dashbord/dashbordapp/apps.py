from django.apps import AppConfig


class DashbordappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dashbordapp'
