from django.urls import path
from . import views
from .views import *
urlpatterns = [

    path('', views.index, name="index"),
    path('get-json-data/', views.get_json_data, name='get_json_data'),
    path('chart/', views.chart, name="chart"),
    path('table/', views.table, name="table"),
    # path('chart/', views.chart, name="deploye"),

]
