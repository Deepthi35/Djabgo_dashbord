/*/ // Worldwide Sales Chart
    var ctx1 = $("#worldwide-sales").get(0).getContext("2d");
    
    var myChart1 = new Chart(ctx1, {
        type: "bar",
        data: {
            labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
            datasets: [{
                label: '# of Votes',
                data: [12, 19, 3, 5, 2, 3],
                borderWidth: 1,
                backgroundColor: "rgba(235, 22, 22, .7)"
            }]
        },
        options: {
            responsive: true
        }
    }); 

*/
  /*  // Salse & Revenue Chart
    var ctx2 = $("#salse-revenue").get(0).getContext("2d");
    var myChart2 = new Chart(ctx2, {
        type: "line",
        data: {
            labels: ["2016", "2017", "2018", "2019", "2020", "2021", "2022"],
            datasets: [{
                    label: "Salse",
                    data: [15, 30, 55, 45, 70, 65, 85],
                    backgroundColor: "rgba(235, 22, 22, .7)",
                    fill: true
                },
                {
                    label: "Revenue",
                    data: [99, 135, 170, 130, 190, 180, 270],
                    backgroundColor: "rgba(235, 22, 22, .5)",
                    fill: true
                }
            ]
            },
        options: {
            responsive: true
        }
    });*/

    



var BarsChart = (function() {

    // Variables
    var $chart = document.getElementById('worldwide-sales');

    // Methods
    var groupedData = {};

    // Fetch data from the new server endpoint
    fetch('/get-json-data/')
        .then(response => response.json())
        .then(jsonData => {
            for (var json_data_entry of jsonData) {
                var department = json_data_entry.department;
                var monthlyincome = json_data_entry.monthlyincome;

                if (!(department in groupedData)) {
                    groupedData[department] = [];
                }

                groupedData[department].push(monthlyincome);
            }

            initChart($chart);
        })
        .catch(error => console.error('Error fetching data:', error));

    // Init chart
    function initChart($chart) {
        var labels = Object.keys(groupedData);
        var datasets = [];

        for (var department in groupedData) {
            datasets.push({
                label: department,
                data: groupedData[department],
                backgroundColor: ["#00FFFF", "rgba(255, 51, 255, 0.5)", "#FFFF00"],
                borderColor: "rgba(54, 162, 235, 1)",
                borderWidth: 2
            });
        }

        var ordersChart = new Chart($chart, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: datasets
            }
        });
    }

})();

// line chart on index page


var BarsChart = (function() {

    // Variables
    var $chart = document.getElementById('salse-revenue');

    // Methods
    var groupedData = {};

    // Fetch data from the new server endpoint
    fetch('/get-json-data/')
        .then(response => response.json())
        .then(jsonData => {
            for (var json_data_entry of jsonData) {
                var department = json_data_entry.department;
                var monthlyincome = json_data_entry.monthlyincome;

                if (!(department in groupedData)) {
                    groupedData[department] = [];
                }

                groupedData[department].push(monthlyincome);
            }

            initChart($chart);
        })
        .catch(error => console.error('Error fetching data:', error));

    // Init chart
    function initChart($chart) {
        var labels = Object.keys(groupedData);
        var datasets = [];

        for (var department in groupedData) {
            datasets.push({
                label: department,
                data: groupedData[department],
                backgroundColor: ["#00FFFF", "rgba(255, 51, 255, 0.5)", "#FFFF00"],
                borderColor: "rgba(54, 162, 235, 1)",
                borderWidth: 2
            });
        }

        var ordersChart = new Chart($chart, {
            type: 'line',
            data: {
                labels: labels,
                datasets: datasets
            }
        });
    }

})();

// line chart on index page

